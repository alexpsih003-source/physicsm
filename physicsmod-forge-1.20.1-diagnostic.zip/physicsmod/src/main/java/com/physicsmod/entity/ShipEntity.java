package com.physicsmod.entity;

import com.physicsmod.ModRegistry;
import com.physicsmod.block.WheelMountBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.entity.IEntityAdditionalSpawnData;
import net.minecraftforge.network.NetworkHooks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Фізичний об'єкт: набір блоків, що їде/летить як єдине ціле. Потужність береться з обертання Create. */
public class ShipEntity extends Entity implements IEntityAdditionalSpawnData {
    /** speed - швидкість обертання (RPM) вала Create цього блоку в момент збірки. */
    public record ShipBlock(int x, int y, int z, BlockState state, float speed) {}

    private List<ShipBlock> blocks = new ArrayList<>();
    private List<ShipBlock> renderBlocks = new ArrayList<>();
    private int sx = 1, sy = 1, sz = 1;
    private int helmX, helmY, helmZ;
    private float forwardYaw;

    // характеристики з блоків
    private int wheelCount, propCount, sails, handles, gimbals, balloons, burners;
    private double wheelPower, propF, propB, propUp; // залежать від RPM вала Create
    private double lift; // 0..1

    private static final EntityDataAccessor<Byte> THROTTLE =
            SynchedEntityData.defineId(ShipEntity.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Float> STEER =
            SynchedEntityData.defineId(ShipEntity.class, EntityDataSerializers.FLOAT);
    public float propAngle, propAngleO;
    public float wheelRoll, wheelRollO;

    private double speed;
    private float inForward, inTurn, inVert;
    private int idleTicks;

    private int lerpSteps;
    private double lerpX, lerpY, lerpZ;
    private float lerpYaw;

    public ShipEntity(EntityType<? extends ShipEntity> type, Level level) {
        super(type, level);
    }

    // ---------- дані ----------

    private static double rpmFactor(float rpm) {
        return Mth.clamp(Math.abs(rpm) / 32.0, 0.0, 4.0); // 32 RPM = 1 одиниця, максимум на 128 RPM
    }

    public void setBlocks(int sx, int sy, int sz, List<ShipBlock> list, int hx, int hy, int hz, float forwardYaw) {
        this.sx = Math.max(1, sx);
        this.sy = Math.max(1, sy);
        this.sz = Math.max(1, sz);
        this.blocks = list;
        this.helmX = hx;
        this.helmY = hy;
        this.helmZ = hz;
        this.forwardYaw = forwardYaw;

        Map<Long, ShipBlock> map = new HashMap<>();
        for (ShipBlock b : list) map.put(BlockPos.asLong(b.x(), b.y(), b.z()), b);

        wheelCount = propCount = sails = handles = gimbals = balloons = burners = 0;
        wheelPower = propF = propB = propUp = 0;
        for (ShipBlock b : list) {
            BlockState st = b.state();
            if (st.is(ModRegistry.WHEEL_MOUNT.get())) {
                if (st.getValue(WheelMountBlock.TIRE)) { // без шини колесо не працює
                    wheelCount++;
                    wheelPower += rpmFactor(b.speed());
                }
            } else if (st.is(ModRegistry.PROPELLER.get())) {
                Direction d = st.getValue(DirectionalBlock.FACING);
                ShipBlock back = map.get(BlockPos.asLong(b.x() - d.getStepX(), b.y() - d.getStepY(), b.z() - d.getStepZ()));
                // пропелер працює лише впритул до підшипника, що дивиться в той самий бік
                if (back != null && back.state().is(ModRegistry.BEARING.get())
                        && back.state().getValue(DirectionalBlock.FACING) == d) {
                    double f = rpmFactor(back.speed());
                    propCount++;
                    if (d == Direction.UP) propUp += f;
                    else if (d.getAxis().isHorizontal()) {
                        float diff = Math.abs(Mth.wrapDegrees(d.toYRot() - forwardYaw));
                        if (diff < 1.0F) propF += f;
                        else if (diff > 179.0F) propB += f;
                    }
                }
            } else if (st.is(ModRegistry.SAIL.get())) sails++;
            else if (st.is(ModRegistry.HANDLE.get())) handles++;
            else if (st.is(ModRegistry.GIMBAL.get())) gimbals++;
            else if (st.is(ModRegistry.ENVELOPE.get())) balloons++;
            else if (st.is(ModRegistry.BURNER.get())) burners++;
        }
        this.lift = Mth.clamp(Math.min(balloons, burners * 24) / (double) Math.max(1, list.size()), 0.0, 1.0);
        computeRenderBlocks();
        refreshDimensions();
    }

    /** На клієнті малюємо тільки блоки, що мають хоча б одну відкриту сторону. */
    private void computeRenderBlocks() {
        Set<Long> set = new HashSet<>();
        for (ShipBlock b : blocks) set.add(BlockPos.asLong(b.x(), b.y(), b.z()));
        List<ShipBlock> visible = new ArrayList<>();
        for (ShipBlock b : blocks) {
            int x = b.x(), y = b.y(), z = b.z();
            if (!set.contains(BlockPos.asLong(x + 1, y, z)) || !set.contains(BlockPos.asLong(x - 1, y, z))
                    || !set.contains(BlockPos.asLong(x, y + 1, z)) || !set.contains(BlockPos.asLong(x, y - 1, z))
                    || !set.contains(BlockPos.asLong(x, y, z + 1)) || !set.contains(BlockPos.asLong(x, y, z - 1))
                    || b.state().is(ModRegistry.WHEEL_MOUNT.get())) {
                visible.add(b);
            }
        }
        this.renderBlocks = visible;
    }

    public int getSizeX() { return sx; }
    public int getSizeZ() { return sz; }
    public float getForwardYaw() { return forwardYaw; }
    public float getSteer() { return entityData.get(STEER); }
    public List<ShipBlock> getRenderBlocks() { return renderBlocks; }
    public int getWheels() { return wheelCount; }
    public int getPropellers() { return propCount; }
    public int getSails() { return sails; }
    public int getLiftBlocks() { return Math.min(balloons, burners * 24); }
    public boolean isThrottling() { return entityData.get(THROTTLE) != 0; }

    public void setInput(float forward, float turn, float vertical) {
        this.inForward = Mth.clamp(forward, -1.0F, 1.0F);
        this.inTurn = Mth.clamp(turn, -1.0F, 1.0F);
        this.inVert = Mth.clamp(vertical, -1.0F, 1.0F);
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return EntityDimensions.fixed(Math.max(sx, sz), sy);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(THROTTLE, (byte) 0);
        entityData.define(STEER, 0.0F);
    }

    // ---------- фізика ----------

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            clientLerp();
        } else {
            serverPhysics();
        }
    }

    private void serverPhysics() {
        boolean hasDriver = getFirstPassenger() != null;
        if (!hasDriver) {
            inForward = 0;
            inTurn = 0;
            inVert = 0;
        }
        boolean ground = onGround();
        int mass = Math.max(1, blocks.size());

        double accelGround = wheelPower <= 0 ? 0 : Mth.clamp(wheelPower / mass * 0.3, 0.004, 0.06);
        double accelFwd = propF <= 0 ? 0 : Mth.clamp(propF / mass * 0.6, 0.002, 0.05);
        double accelBack = propB <= 0 ? 0 : Mth.clamp(propB / mass * 0.6, 0.002, 0.03);
        double accelSail = sails <= 0 ? 0 : Mth.clamp(sails * 0.18 / mass, 0.001, 0.03);
        float handleBoost = handles > 0 ? 1.5F : 1.0F;

        // кермові колеса повертаються плавно (синхронізується з клієнтом для анімації)
        float steerTarget = inTurn * 30.0F;
        float steerCur = entityData.get(STEER);
        float steerNext = steerCur + (steerTarget - steerCur) * 0.4F;
        if (Math.abs(steerNext - steerTarget) < 0.5F) steerNext = steerTarget;
        if (steerNext != steerCur) entityData.set(STEER, steerNext);

        double potential = lift + (propUp > 0 ? Mth.clamp(propUp * 0.9 / mass / 0.04, 0.0, 1.0) : 0.0);
        boolean holding = hasDriver && gimbals > 0 && inVert == 0 && !ground && potential >= 1.0;

        boolean throttle = (inForward > 0 && propF > 0) || (inForward < 0 && propB > 0)
                || (inVert > 0 && propUp > 0) || (holding && propUp > 0);
        entityData.set(THROTTLE, (byte) (throttle ? 1 : 0));

        // сплячка: припаркований об'єкт майже не вантажить процесор
        boolean noInput = inForward == 0 && inTurn == 0 && inVert == 0;
        if (ground && noInput && speed == 0 && lift == 0 && Math.abs(getDeltaMovement().y) < 0.05) {
            if (++idleTicks % 10 != 0) return;
        } else {
            idleTicks = 0;
        }

        // --- горизонталь ---
        double maxSpeed = Math.max(0.35, Math.max(ground && wheelPower > 0 ? 0.6 : 0, propF > 0 ? 0.7 : 0));
        if (ground && wheelPower > 0) speed += inForward * accelGround;
        if (inForward > 0) speed += accelFwd;
        else if (inForward < 0) speed -= accelBack;
        speed += inForward * accelSail;
        if (ground && inVert < 0) speed *= 0.7;

        double friction;
        if (ground) {
            if (wheelPower > 0) friction = inForward == 0 ? 0.93 : 0.99;
            else friction = (propF > 0 || propB > 0 || sails > 0) ? 0.95 : 0.8;
        } else {
            friction = inForward == 0 ? 0.985 : 0.995;
        }
        speed = Mth.clamp(speed * friction, -maxSpeed * 0.5, maxSpeed);
        if (Math.abs(speed) < 0.001) speed = 0;

        // --- поворот ---
        if (ground && wheelPower > 0) {
            float rate = (float) (3.0 * Math.min(1.0, Math.abs(speed) / 0.15)) * handleBoost;
            float dir = speed >= 0 ? 1.0F : -1.0F;
            setYRot(getYRot() + inTurn * rate * dir);
        } else if (!ground && (propF > 0 || lift > 0 || propUp > 0 || sails > 0)) {
            setYRot(getYRot() + inTurn * 2.0F * handleBoost);
        } else if (ground && (propF > 0 || sails > 0) && Math.abs(speed) > 0.05) {
            setYRot(getYRot() + inTurn * 1.5F * handleBoost * Math.signum((float) speed));
        }

        // --- вертикаль ---
        double vy = getDeltaMovement().y;
        if (holding) vy *= 0.5;
        else vy -= 0.04 * (1.0 - lift);
        if (inVert > 0) {
            if (lift > 0) vy += 0.015 * lift;
            if (propUp > 0) vy += Mth.clamp(propUp * 0.9 / mass, 0.0, 0.07);
        } else if (inVert < 0 && lift > 0) {
            vy -= 0.015;
        }
        if (sails > 0 && !ground) vy = Math.max(vy, -0.25);
        vy *= (lift > 0 || propUp > 0) ? 0.92 : 0.98;
        if (isInWater()) vy = vy * 0.7 + 0.06;

        double rad = Math.toRadians(getYRot() + forwardYaw);
        setDeltaMovement(-Math.sin(rad) * speed, vy, Math.cos(rad) * speed);
        move(MoverType.SELF, getDeltaMovement());
        if (horizontalCollision) speed *= 0.4;
    }

    /** Підвіска коліс дозволяє заїжджати на 1 блок. */
    public float maxUpStep() {
        return wheelPower > 0 ? 1.0F : 0.6F;
    }

    // ---------- клієнт ----------

    @Override
    public void lerpTo(double x, double y, double z, float yRot, float xRot, int steps, boolean teleport) {
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpYaw = yRot;
        this.lerpSteps = Math.max(1, steps);
    }

    private void clientLerp() {
        propAngleO = propAngle;
        wheelRollO = wheelRoll;
        if (isThrottling()) {
            propAngle += 45.0F;
            if (propAngle > 3600.0F) { propAngle -= 3600.0F; propAngleO -= 3600.0F; }
        }
        if (lerpSteps > 0) {
            double nx = getX() + (lerpX - getX()) / lerpSteps;
            double ny = getY() + (lerpY - getY()) / lerpSteps;
            double nz = getZ() + (lerpZ - getZ()) / lerpSteps;
            float nyaw = getYRot() + Mth.wrapDegrees(lerpYaw - getYRot()) / lerpSteps;
            lerpSteps--;
            setPos(nx, ny, nz);
            setRot(nyaw, 0.0F);
        }
        // кочення коліс: пройдена відстань вздовж "переду" об'єкта
        double mx = getX() - xo, mz = getZ() - zo;
        double dist = Math.hypot(mx, mz);
        if (dist > 1.0E-4) {
            double rad = Math.toRadians(getYRot() + forwardYaw);
            double along = mx * -Math.sin(rad) + mz * Math.cos(rad);
            wheelRoll += (float) (dist * 163.0 * Math.signum(along));
            if (Math.abs(wheelRoll) > 3600.0F) { wheelRoll %= 360.0F; wheelRollO = wheelRoll; }
        }
    }

    // ---------- взаємодія ----------

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (player.getItemInHand(hand).is(ModRegistry.BLUEPRINT.get())) {
            if (!level().isClientSide) {
                player.displayClientMessage(Component.translatable("message.physicsmod.stats",
                        blocks.size(), wheelCount, propCount, sails, getLiftBlocks(), gimbals,
                        Math.round((wheelPower + propF + propB + propUp) * 25)), false);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (player.isSecondaryUseActive()) {
            disassemble();
            return InteractionResult.CONSUME;
        }
        return player.startRiding(this) ? InteractionResult.CONSUME : InteractionResult.PASS;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override public boolean isPickable() { return !isRemoved(); }
    @Override public boolean canBeCollidedWith() { return true; }
    @Override public boolean isPushable() { return false; }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction callback) {
        if (!hasPassenger(passenger)) return;
        double lx = helmX - sx / 2.0 + 0.5;
        double lz = helmZ - sz / 2.0 + 0.5;
        double rad = Math.toRadians(getYRot());
        double cos = Math.cos(rad), sin = Math.sin(rad);
        callback.accept(passenger, getX() + lx * cos - lz * sin, getY() + helmY + 0.85, getZ() + lx * sin + lz * cos);
    }

    /** Розбирає об'єкт назад у блоки (вирівнювання по сітці, поворот на кратний 90°). */
    public void disassemble() {
        if (!(level() instanceof ServerLevel sl)) return;
        ejectPassengers();
        GlueData glue = GlueData.get(sl);

        int q = Math.floorMod(Math.round(getYRot() / 90.0F), 4);
        Rotation rot = switch (q) {
            case 1 -> Rotation.CLOCKWISE_90;
            case 2 -> Rotation.CLOCKWISE_180;
            case 3 -> Rotation.COUNTERCLOCKWISE_90;
            default -> Rotation.NONE;
        };
        double theta = Math.toRadians(q * 90.0);
        double cos = Math.cos(theta), sin = Math.sin(theta);

        int effX = (q % 2 == 0) ? sx : sz;
        int effZ = (q % 2 == 0) ? sz : sx;
        double cx = (effX % 2 == 0) ? Math.round(getX()) : Math.floor(getX()) + 0.5;
        double cz = (effZ % 2 == 0) ? Math.round(getZ()) : Math.floor(getZ()) + 0.5;
        int baseY = (int) Math.round(getY());

        for (ShipBlock b : blocks) {
            double lx = b.x() - sx / 2.0 + 0.5;
            double lz = b.z() - sz / 2.0 + 0.5;
            BlockPos pos = BlockPos.containing(cx + lx * cos - lz * sin, baseY + b.y() + 0.5, cz + lx * sin + lz * cos);
            BlockState state = b.state().rotate(rot);
            BlockState existing = sl.getBlockState(pos);
            if (existing.isAir() || existing.canBeReplaced()) {
                sl.setBlock(pos, state, Block.UPDATE_ALL);
                if (!ShipAssembler.isModPart(state)) glue.add(pos);
            } else {
                Block.popResource(sl, pos, new ItemStack(state.getBlock()));
            }
        }
        discard();
    }

    // ---------- збереження / синхронізація ----------

    private CompoundTag saveShip() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("sx", sx);
        tag.putInt("sy", sy);
        tag.putInt("sz", sz);
        tag.putInt("hx", helmX);
        tag.putInt("hy", helmY);
        tag.putInt("hz", helmZ);
        tag.putFloat("fyaw", forwardYaw);
        ListTag palette = new ListTag();
        Map<BlockState, Integer> index = new HashMap<>();
        int[] data = new int[blocks.size() * 5];
        for (int i = 0; i < blocks.size(); i++) {
            ShipBlock b = blocks.get(i);
            Integer id = index.get(b.state());
            if (id == null) {
                id = palette.size();
                palette.add(NbtUtils.writeBlockState(b.state()));
                index.put(b.state(), id);
            }
            data[i * 5] = b.x();
            data[i * 5 + 1] = b.y();
            data[i * 5 + 2] = b.z();
            data[i * 5 + 3] = id;
            data[i * 5 + 4] = Float.floatToIntBits(b.speed());
        }
        tag.put("Palette", palette);
        tag.putIntArray("Blocks", data);
        return tag;
    }

    private void loadShip(CompoundTag tag) {
        if (tag == null || tag.isEmpty()) return;
        ListTag pal = tag.getList("Palette", Tag.TAG_COMPOUND);
        List<BlockState> palette = new ArrayList<>();
        for (int i = 0; i < pal.size(); i++) {
            palette.add(NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), pal.getCompound(i)));
        }
        int[] data = tag.getIntArray("Blocks");
        List<ShipBlock> list = new ArrayList<>();
        for (int i = 0; i + 4 < data.length; i += 5) {
            list.add(new ShipBlock(data[i], data[i + 1], data[i + 2], palette.get(data[i + 3]), Float.intBitsToFloat(data[i + 4])));
        }
        setBlocks(tag.getInt("sx"), tag.getInt("sy"), tag.getInt("sz"), list,
                tag.getInt("hx"), tag.getInt("hy"), tag.getInt("hz"), tag.getFloat("fyaw"));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.put("Ship", saveShip());
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        loadShip(tag.getCompound("Ship"));
    }

    @Override
    public void writeSpawnData(FriendlyByteBuf buf) {
        buf.writeNbt(saveShip());
    }

    @Override
    public void readSpawnData(FriendlyByteBuf buf) {
        loadShip(buf.readNbt());
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
