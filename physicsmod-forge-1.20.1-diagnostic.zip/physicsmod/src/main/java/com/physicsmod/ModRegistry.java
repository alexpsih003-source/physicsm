package com.physicsmod;

import com.physicsmod.block.AssemblerBlock;
import com.physicsmod.block.HandleBlock;
import com.physicsmod.block.DriveBlockEntity;
import com.physicsmod.block.HelmBlock;
import com.physicsmod.block.PropellerBearingBlock;
import com.physicsmod.block.PropellerBlock;
import com.physicsmod.block.SailBlock;
import com.physicsmod.block.WheelMountBlock;
import com.physicsmod.entity.ShipEntity;
import com.physicsmod.item.AviatorMaterial;
import com.physicsmod.item.HoneyGlueItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public final class ModRegistry {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, PhysicsMod.MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, PhysicsMod.MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, PhysicsMod.MODID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, PhysicsMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, PhysicsMod.MODID);

    private static BlockBehaviour.Properties metal() {
        return BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(3.0F).sound(SoundType.METAL);
    }

    // ---- блоки ----
    public static final RegistryObject<Block> ASSEMBLER = block("physics_assembler", () -> new AssemblerBlock(metal()));
    public static final RegistryObject<Block> HELM = block("helm",
            () -> new HelmBlock(BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(2.0F).sound(SoundType.WOOD)));
    public static final RegistryObject<Block> WHEEL_MOUNT = block("wheel_mount", () -> new WheelMountBlock(metal().noOcclusion()));
    public static final RegistryObject<Block> BEARING = block("propeller_bearing", () -> new PropellerBearingBlock(metal()));
    public static final RegistryObject<Block> PROPELLER = block("andesite_propeller",
            () -> new PropellerBlock(BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(1.5F).sound(SoundType.STONE).noOcclusion()));
    public static final RegistryObject<Block> HANDLE = block("handle", () -> new HandleBlock(metal().noOcclusion()));
    public static final RegistryObject<Block> SAIL = block("symmetric_sail",
            () -> new SailBlock(BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(0.5F).sound(SoundType.WOOL).noOcclusion()));
    public static final RegistryObject<Block> ENVELOPE = block("envelope",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).strength(0.5F).sound(SoundType.WOOL)));
    public static final RegistryObject<Block> BURNER = block("hot_air_burner",
            () -> new Block(metal().lightLevel(s -> 12)));
    public static final RegistryObject<Block> GIMBAL = block("gimbal_sensor", () -> new Block(metal()));

    public static final RegistryObject<BlockEntityType<DriveBlockEntity>> DRIVE_BE = BLOCK_ENTITIES.register("drive",
            () -> BlockEntityType.Builder.of((pos, state) -> new DriveBlockEntity(ModRegistry.DRIVE_BE.get(), pos, state),
                    WHEEL_MOUNT.get(), BEARING.get()).build(null));

    // ---- предмети ----
    public static final RegistryObject<Item> TIRE = ITEMS.register("tire", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> HONEY_GLUE = ITEMS.register("honey_glue", () -> new HoneyGlueItem(new Item.Properties().durability(32)));
    public static final RegistryObject<Item> BLUEPRINT = ITEMS.register("blueprint", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> GOGGLES = ITEMS.register("aviator_goggles",
            () -> new ArmorItem(AviatorMaterial.INSTANCE, ArmorItem.Type.HELMET, new Item.Properties()));

    public static final RegistryObject<EntityType<ShipEntity>> SHIP = ENTITIES.register("ship",
            () -> EntityType.Builder.<ShipEntity>of(ShipEntity::new, MobCategory.MISC)
                    .sized(1.0F, 1.0F).clientTrackingRange(8).updateInterval(2).fireImmune().build("ship"));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("physics",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.physicsmod"))
                    .icon(() -> new ItemStack(ASSEMBLER.get()))
                    .displayItems((params, out) -> {
                        out.accept(ASSEMBLER.get());
                        out.accept(HELM.get());
                        out.accept(HONEY_GLUE.get());
                        out.accept(WHEEL_MOUNT.get());
                        out.accept(TIRE.get());
                        out.accept(BEARING.get());
                        out.accept(PROPELLER.get());
                        out.accept(ENVELOPE.get());
                        out.accept(BURNER.get());
                        out.accept(GIMBAL.get());
                        out.accept(SAIL.get());
                        out.accept(HANDLE.get());
                        out.accept(BLUEPRINT.get());
                        out.accept(GOGGLES.get());
                    }).build());

    private static RegistryObject<Block> block(String name, Supplier<Block> sup) {
        RegistryObject<Block> obj = BLOCKS.register(name, sup);
        ITEMS.register(name, () -> new BlockItem(obj.get(), new Item.Properties()));
        return obj;
    }

    private ModRegistry() {}
}
