package com.physicsmod.client;

import com.physicsmod.PhysicsMod;
import com.physicsmod.entity.ShipEntity;
import com.physicsmod.network.PhysicsNetwork;
import com.physicsmod.network.ShipInputPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** W/S - вперед/назад, A/D - поворот, Пробіл - вгору, Ctrl - вниз/гальмо, Shift - вийти. */
@Mod.EventBusSubscriber(modid = PhysicsMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ClientForgeEvents {
    private static float lastF, lastT, lastV;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || !(player.getVehicle() instanceof ShipEntity)) return;
        Options o = mc.options;
        float f = (o.keyUp.isDown() ? 1 : 0) - (o.keyDown.isDown() ? 1 : 0);
        float t = (o.keyRight.isDown() ? 1 : 0) - (o.keyLeft.isDown() ? 1 : 0);
        float v = (o.keyJump.isDown() ? 1 : 0) - (o.keySprint.isDown() ? 1 : 0);
        // шлемо тільки зміни (економія трафіку)
        if (f != lastF || t != lastT || v != lastV) {
            lastF = f; lastT = t; lastV = v;
            PhysicsNetwork.CHANNEL.sendToServer(new ShipInputPacket(f, t, v));
        }
    }
}
