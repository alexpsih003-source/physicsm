package com.physicsmod.block;

import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

/** Спільний блок-ентіті для кріплення колеса і підшипника вінта: споживає обертання Create. */
public class DriveBlockEntity extends KineticBlockEntity {
    public static final float STRESS_IMPACT = 4.0F; // SU на 1 RPM

    public DriveBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    @Override
    public float calculateStressApplied() {
        this.lastStressApplied = STRESS_IMPACT;
        return STRESS_IMPACT;
    }
}
