package com.physicsmod.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashSet;
import java.util.Set;

/** Запам'ятовує, які блоки склеєні медовим клеєм. */
public class GlueData extends SavedData {
    private final Set<Long> glued = new HashSet<>();

    public static GlueData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(GlueData::load, GlueData::new, "physicsmod_glue");
    }

    public static GlueData load(CompoundTag tag) {
        GlueData d = new GlueData();
        for (long v : tag.getLongArray("glue")) d.glued.add(v);
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putLongArray("glue", glued.stream().mapToLong(Long::longValue).toArray());
        return tag;
    }

    public boolean contains(BlockPos p) { return glued.contains(p.asLong()); }

    public boolean add(BlockPos p) {
        boolean r = glued.add(p.asLong());
        if (r) setDirty();
        return r;
    }

    public boolean remove(BlockPos p) {
        boolean r = glued.remove(p.asLong());
        if (r) setDirty();
        return r;
    }
}
