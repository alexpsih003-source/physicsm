package com.physicsmod.network;

import com.physicsmod.entity.ShipEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record ShipInputPacket(float forward, float turn, float vertical) {
    public static void encode(ShipInputPacket m, FriendlyByteBuf buf) {
        buf.writeFloat(m.forward);
        buf.writeFloat(m.turn);
        buf.writeFloat(m.vertical);
    }

    public static ShipInputPacket decode(FriendlyByteBuf buf) {
        return new ShipInputPacket(buf.readFloat(), buf.readFloat(), buf.readFloat());
    }

    public static void handle(ShipInputPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null && player.getVehicle() instanceof ShipEntity ship) {
                ship.setInput(m.forward, m.turn, m.vertical);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
