package com.physicsmod.client;

import com.physicsmod.ModRegistry;
import com.physicsmod.PhysicsMod;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.ModelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = PhysicsMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModRegistry.SHIP.get(), ShipRenderer::new);
        event.registerBlockEntityRenderer(ModRegistry.DRIVE_BE.get(), DriveRenderer::new);
    }

    /** Окрема модель колеса: потрібна, щоб крутити/повертати колесо на рухомому об'єкті. */
    @SubscribeEvent
    public static void registerModels(ModelEvent.RegisterAdditional event) {
        event.register(ShipRenderer.WHEEL_MODEL);
    }
}
