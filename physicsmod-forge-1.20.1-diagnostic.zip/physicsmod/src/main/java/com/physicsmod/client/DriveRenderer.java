package com.physicsmod.client;

import com.physicsmod.block.DriveBlockEntity;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.world.level.block.state.BlockState;

/** Малює вал Create, що обертається всередині кріплення колеса / підшипника. */
public class DriveRenderer extends KineticBlockEntityRenderer<DriveBlockEntity> {
    public DriveRenderer(BlockEntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    protected BlockState getRenderedBlockState(DriveBlockEntity be) {
        return shaft(getRotationAxisOf(be));
    }
}
