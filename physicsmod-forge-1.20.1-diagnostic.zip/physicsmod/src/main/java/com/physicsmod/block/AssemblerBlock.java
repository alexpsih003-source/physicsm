package com.physicsmod.block;

import com.physicsmod.entity.ShipAssembler;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Фізичний асемблер: ПКМ збирає склеєні блоки та деталі мода в рухомий об'єкт. */
public class AssemblerBlock extends Block {
    public AssemblerBlock(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        ShipAssembler.assemble((ServerLevel) level, pos, player);
        return InteractionResult.CONSUME;
    }
}
