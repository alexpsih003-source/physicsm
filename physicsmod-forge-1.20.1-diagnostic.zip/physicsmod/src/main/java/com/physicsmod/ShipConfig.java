package com.physicsmod;

import net.minecraftforge.common.ForgeConfigSpec;

/** Налаштування продуктивності. Файл: config/physicsmod-common.toml */
public final class ShipConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue MAX_BLOCKS;
    public static final ForgeConfigSpec.IntValue RENDER_DISTANCE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        MAX_BLOCKS = b.comment("Макс. блоків в одному фізичному об'єкті (менше = легше для телефону)")
                .defineInRange("maxBlocks", 300, 10, 3000);
        RENDER_DISTANCE = b.comment("Дальність, на якій малюються фізичні об'єкти (блоки)")
                .defineInRange("renderDistance", 48, 8, 256);
        SPEC = b.build();
    }

    private ShipConfig() {}
}
