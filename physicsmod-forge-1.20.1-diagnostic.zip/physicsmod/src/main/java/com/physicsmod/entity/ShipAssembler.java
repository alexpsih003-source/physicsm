package com.physicsmod.entity;

import com.physicsmod.ModRegistry;
import com.physicsmod.PhysicsMod;
import com.physicsmod.ShipConfig;
import com.physicsmod.block.HelmBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Збирає з'єднані деталі мода та склеєні блоки навколо асемблера в один ShipEntity. */
public final class ShipAssembler {

    public static void assemble(ServerLevel level, BlockPos start, Player player) {
        GlueData glue = GlueData.get(level);
        int max = ShipConfig.MAX_BLOCKS.get();
        Map<BlockPos, BlockState> found = new LinkedHashMap<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        found.put(start, level.getBlockState(start));
        queue.add(start);

        while (!queue.isEmpty()) {
            BlockPos p = queue.poll();
            for (Direction d : Direction.values()) {
                BlockPos n = p.relative(d);
                if (found.containsKey(n)) continue;
                BlockState s = level.getBlockState(n);
                if (!isShipBlock(level, n, s)) continue;
                if (!(isModPart(s) || glue.contains(n))) continue;
                if (found.size() >= max) {
                    player.displayClientMessage(Component.translatable("message.physicsmod.too_big", max), true);
                    return;
                }
                found.put(n, s);
                queue.add(n);
            }
        }

        BlockPos helmPos = null;
        BlockState helmState = null;
        for (Map.Entry<BlockPos, BlockState> e : found.entrySet()) {
            if (e.getValue().is(ModRegistry.HELM.get())) {
                helmPos = e.getKey();
                helmState = e.getValue();
                break;
            }
        }
        if (helmPos == null) {
            player.displayClientMessage(Component.translatable("message.physicsmod.no_helm"), true);
            return;
        }

        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        for (BlockPos p : found.keySet()) {
            minX = Math.min(minX, p.getX()); maxX = Math.max(maxX, p.getX());
            minY = Math.min(minY, p.getY()); maxY = Math.max(maxY, p.getY());
            minZ = Math.min(minZ, p.getZ()); maxZ = Math.max(maxZ, p.getZ());
        }

        // 1) скільки генераторів Create (мотор, водяне колесо...) є на борту
        int generators = 0;
        for (BlockPos p : found.keySet()) {
            BlockEntity be = level.getBlockEntity(p);
            if (be instanceof KineticBlockEntity k && k.getGeneratedSpeed() != 0) generators++;
        }
        boolean hasDrive = false;
        // 2) знімаємо обертання вала кожної деталі приводу
        List<ShipEntity.ShipBlock> list = new ArrayList<>();
        for (Map.Entry<BlockPos, BlockState> e : found.entrySet()) {
            BlockPos p = e.getKey();
            BlockState st = e.getValue();
            float rpm = 0;
            if (st.is(ModRegistry.WHEEL_MOUNT.get()) || st.is(ModRegistry.BEARING.get())) {
                hasDrive = true;
                BlockEntity be = level.getBlockEntity(p);
                if (generators > 0 && be instanceof KineticBlockEntity k) rpm = k.getSpeed();
            }
            list.add(new ShipEntity.ShipBlock(p.getX() - minX, p.getY() - minY, p.getZ() - minZ, st, rpm));
        }

        ShipEntity ship = new ShipEntity(ModRegistry.SHIP.get(), level);
        ship.setBlocks(maxX - minX + 1, maxY - minY + 1, maxZ - minZ + 1, list,
                helmPos.getX() - minX, helmPos.getY() - minY, helmPos.getZ() - minZ,
                helmState.getValue(HelmBlock.FACING).toYRot());
        ship.moveTo((minX + maxX + 1) / 2.0, minY, (minZ + maxZ + 1) / 2.0, 0.0F, 0.0F);

        for (BlockPos p : found.keySet()) {
            glue.remove(p);
            level.setBlock(p, Blocks.AIR.defaultBlockState(),
                    Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE | Block.UPDATE_SUPPRESS_DROPS);
        }
        level.addFreshEntity(ship);
        player.startRiding(ship);
        if (hasDrive && generators == 0) {
            player.displayClientMessage(Component.translatable("message.physicsmod.no_engine"), false);
        }
        player.displayClientMessage(Component.translatable("message.physicsmod.assembled",
                list.size(), ship.getWheels(), ship.getPropellers(), ship.getSails(), ship.getLiftBlocks()), true);
    }

    public static boolean isModPart(BlockState s) {
        var key = ForgeRegistries.BLOCKS.getKey(s.getBlock());
        return key != null && key.getNamespace().equals(PhysicsMod.MODID);
    }

    public static boolean isCreate(BlockState s) {
        var key = ForgeRegistries.BLOCKS.getKey(s.getBlock());
        return key != null && key.getNamespace().equals("create");
    }

    public static boolean isTerrain(BlockState s) {
        return s.is(BlockTags.DIRT) || s.is(BlockTags.SAND) || s.is(BlockTags.SNOW) || s.is(BlockTags.LEAVES)
                || s.is(BlockTags.BASE_STONE_OVERWORLD) || s.is(BlockTags.BASE_STONE_NETHER)
                || s.is(BlockTags.DEEPSLATE_ORE_REPLACEABLES) || s.is(Blocks.GRAVEL) || s.is(Blocks.CLAY);
    }

    public static boolean isShipBlock(ServerLevel level, BlockPos pos, BlockState s) {
        if (s.isAir() || !s.getFluidState().isEmpty() || s.canBeReplaced()) return false;
        if (s.hasBlockEntity() && !isModPart(s) && !isCreate(s)) return false;
        return s.getDestroySpeed(level, pos) >= 0;
    }

    private ShipAssembler() {}
}
