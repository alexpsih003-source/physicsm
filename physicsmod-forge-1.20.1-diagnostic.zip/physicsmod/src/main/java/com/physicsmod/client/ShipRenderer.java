package com.physicsmod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.physicsmod.ModRegistry;
import com.physicsmod.PhysicsMod;
import com.physicsmod.ShipConfig;
import com.physicsmod.block.WheelMountBlock;
import com.physicsmod.entity.ShipEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.joml.Quaternionf;

public class ShipRenderer extends EntityRenderer<ShipEntity> {
    public static final ResourceLocation WHEEL_MODEL = new ResourceLocation(PhysicsMod.MODID, "block/wheel_only");

    public ShipRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(ShipEntity ship, float yaw, float partialTick, PoseStack ps, MultiBufferSource buf, int light) {
        // легкий режим: далекі об'єкти не малюємо взагалі
        double max = ShipConfig.RENDER_DISTANCE.get();
        var cam = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
        if (ship.position().distanceToSqr(cam) > max * max) return;

        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(-yaw));
        ps.translate(-ship.getSizeX() / 2.0, 0.0, -ship.getSizeZ() / 2.0);
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        boolean spin = ship.isThrottling();
        float angle = Mth.lerp(partialTick, ship.propAngleO, ship.propAngle);

        for (ShipEntity.ShipBlock b : ship.getRenderBlocks()) {
            BlockState st = b.state();
            ps.pushPose();
            ps.translate(b.x(), b.y(), b.z());
            if (st.is(ModRegistry.WHEEL_MOUNT.get())) {
                // кріплення без колеса + колесо окремо (воно повертається і крутиться)
                dispatcher.renderSingleBlock(st.setValue(WheelMountBlock.TIRE, false), ps, buf, light, OverlayTexture.NO_OVERLAY);
                if (st.getValue(WheelMountBlock.TIRE)) renderWheel(ship, b, st, partialTick, ps, buf, light);
            } else {
                if (spin && st.is(ModRegistry.PROPELLER.get())) {
                    Direction d = st.getValue(DirectionalBlock.FACING);
                    ps.translate(0.5, 0.5, 0.5);
                    ps.mulPose(new Quaternionf().rotateAxis((float) Math.toRadians(angle), d.getStepX(), d.getStepY(), d.getStepZ()));
                    ps.translate(-0.5, -0.5, -0.5);
                }
                dispatcher.renderSingleBlock(st, ps, buf, light, OverlayTexture.NO_OVERLAY);
            }
            ps.popPose();
        }
        ps.popPose();
        super.render(ship, yaw, partialTick, ps, buf, light);
    }

    private void renderWheel(ShipEntity ship, ShipEntity.ShipBlock b, BlockState st, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        Direction f = st.getValue(WheelMountBlock.HORIZONTAL_FACING);
        int facingY = switch (f) {
            case EAST -> 90;
            case SOUTH -> 180;
            case WEST -> 270;
            default -> 0;
        };
        // вектор "переду" об'єкта в його власних координатах
        double fy = Math.toRadians(ship.getForwardYaw());
        double fx = -Math.sin(fy), fz = Math.cos(fy);
        // положення колеса відносно центру: кермують лише передні колеса
        double lx = b.x() - ship.getSizeX() / 2.0 + 0.5;
        double lz = b.z() - ship.getSizeZ() / 2.0 + 0.5;
        boolean front = lx * fx + lz * fz > -0.5;
        float steer = front ? ship.getSteer() : 0.0F;
        // напрям кочення залежить від того, з якого боку стоїть колесо
        float side = (float) (fz * f.getStepX() - fx * f.getStepZ());
        float roll = -side * Mth.lerp(pt, ship.wheelRollO, ship.wheelRoll);

        BakedModel model = Minecraft.getInstance().getModelManager().getModel(WHEEL_MODEL);
        ps.pushPose();
        // орієнтація як у blockstate
        ps.translate(0.5, 0.5, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(-facingY));
        ps.translate(-0.5, -0.5, -0.5);
        // центр колеса в моделі: (8, 8, 2) / 16
        ps.translate(0.5, 0.0, 0.125);
        ps.mulPose(Axis.YP.rotationDegrees(-steer));
        ps.translate(0.0, 0.5, 0.0);
        ps.mulPose(Axis.ZP.rotationDegrees(roll));
        ps.translate(-0.5, -0.5, -0.125);
        Minecraft.getInstance().getBlockRenderer().getModelRenderer().renderModel(
                ps.last(), buf.getBuffer(RenderType.cutout()), null, model, 1.0F, 1.0F, 1.0F, light, OverlayTexture.NO_OVERLAY);
        ps.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(ShipEntity entity) {
        return InventoryMenu.BLOCK_ATLAS;
    }
}
