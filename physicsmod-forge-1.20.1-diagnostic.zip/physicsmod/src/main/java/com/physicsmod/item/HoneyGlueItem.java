package com.physicsmod.item;

import com.physicsmod.entity.GlueData;
import com.physicsmod.entity.ShipAssembler;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

/** ПКМ по блоку - склеює його і сусідні (до 64 за раз). Shift+ПКМ - розклеює. */
public class HoneyGlueItem extends Item {
    public HoneyGlueItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        ServerLevel sl = (ServerLevel) level;
        Player player = ctx.getPlayer();
        BlockPos start = ctx.getClickedPos();
        if (sl.getBlockState(start).isAir()) return InteractionResult.PASS;

        GlueData glue = GlueData.get(sl);
        boolean remove = player != null && player.isSecondaryUseActive();
        int limit = remove ? 256 : 64;
        int count = 0, processed = 0;

        Set<BlockPos> seen = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        seen.add(start);
        queue.add(start);
        while (!queue.isEmpty() && processed++ < limit) {
            BlockPos p = queue.poll();
            BlockState s = sl.getBlockState(p);
            if (remove) {
                if (glue.remove(p)) count++;
            } else if (!ShipAssembler.isModPart(s) && glue.add(p)) {
                count++;
            }
            for (Direction d : Direction.values()) {
                BlockPos n = p.relative(d);
                if (seen.contains(n)) continue;
                BlockState ns = sl.getBlockState(n);
                boolean ok = remove ? glue.contains(n) : (ShipAssembler.isShipBlock(sl, n, ns) && !ShipAssembler.isTerrain(ns));
                if (ok) {
                    seen.add(n);
                    queue.add(n);
                }
            }
        }

        sl.sendParticles(ParticleTypes.WAX_ON, start.getX() + 0.5, start.getY() + 1.0, start.getZ() + 0.5, 6, 0.3, 0.3, 0.3, 0.0);
        if (player != null) {
            player.displayClientMessage(Component.translatable(remove ? "message.physicsmod.unglued" : "message.physicsmod.glued", count), true);
            if (count > 0 && !player.getAbilities().instabuild) {
                ctx.getItemInHand().hurtAndBreak(1, player, p -> p.broadcastBreakEvent(ctx.getHand()));
            }
        }
        return InteractionResult.CONSUME;
    }
}
