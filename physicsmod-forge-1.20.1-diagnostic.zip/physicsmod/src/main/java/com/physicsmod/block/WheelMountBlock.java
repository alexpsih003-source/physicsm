package com.physicsmod.block;

import com.physicsmod.ModRegistry;
import com.simibubi.create.content.kinetics.base.HorizontalKineticBlock;
import com.simibubi.create.foundation.block.IBE;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Кріплення колеса (Create-блок). Вал під'єднується ззаду (протилежна від колеса сторона).
 * Тягу дає лише з шиною і лише коли вал обертається.
 */
public class WheelMountBlock extends HorizontalKineticBlock implements IBE<DriveBlockEntity> {
    public static final BooleanProperty TIRE = BooleanProperty.create("tire");

    public WheelMountBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(HORIZONTAL_FACING, Direction.NORTH).setValue(TIRE, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(TIRE);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        Direction face = ctx.getClickedFace();
        Direction dir = face.getAxis().isHorizontal() ? face : ctx.getHorizontalDirection().getClockWise();
        return defaultBlockState().setValue(HORIZONTAL_FACING, dir).setValue(TIRE, false);
    }

    @Override
    public Direction.Axis getRotationAxis(BlockState state) {
        return state.getValue(HORIZONTAL_FACING).getAxis();
    }

    @Override
    public boolean hasShaftTowards(LevelReader world, BlockPos pos, BlockState state, Direction face) {
        return face == state.getValue(HORIZONTAL_FACING).getOpposite();
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public Class<DriveBlockEntity> getBlockEntityClass() {
        return DriveBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends DriveBlockEntity> getBlockEntityType() {
        return ModRegistry.DRIVE_BE.get();
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        boolean tired = state.getValue(TIRE);
        if (!tired && held.is(ModRegistry.TIRE.get())) {
            if (!level.isClientSide) {
                level.setBlock(pos, state.setValue(TIRE, true), Block.UPDATE_ALL);
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (tired && held.isEmpty() && player.isSecondaryUseActive()) {
            if (!level.isClientSide) {
                level.setBlock(pos, state.setValue(TIRE, false), Block.UPDATE_ALL);
                player.getInventory().placeItemBackInInventory(new ItemStack(ModRegistry.TIRE.get()));
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }
}
