package com.physicsmod.block;

import com.physicsmod.ModRegistry;
import com.simibubi.create.content.kinetics.base.DirectionalKineticBlock;
import com.simibubi.create.foundation.block.IBE;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

/** Підшипник вінта (Create-блок). FACING = напрямок тяги, вал під'єднується ззаду. */
public class PropellerBearingBlock extends DirectionalKineticBlock implements IBE<DriveBlockEntity> {
    public PropellerBearingBlock(Properties props) {
        super(props);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getNearestLookingDirection());
    }

    @Override
    public Direction.Axis getRotationAxis(BlockState state) {
        return state.getValue(FACING).getAxis();
    }

    @Override
    public boolean hasShaftTowards(LevelReader world, BlockPos pos, BlockState state, Direction face) {
        return face == state.getValue(FACING).getOpposite();
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public Class<DriveBlockEntity> getBlockEntityClass() {
        return DriveBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends DriveBlockEntity> getBlockEntityType() {
        return ModRegistry.DRIVE_BE.get();
    }
}
